
package es.ies.puerto.file.dos;

import java.util.List;

/**
 *   @author: alejandrosalazargonzalez
 *   @version: 1.0.0
 */
public class Pokedex {
    List<Pokemon> pokemons;
}
