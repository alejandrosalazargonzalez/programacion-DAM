package utilidades;

public class UtilClassTest {
    public static final String MESSAGE_ERROR = "NO SE HA OBTENIDO LA RESPUESTA ESPERADA";
}
